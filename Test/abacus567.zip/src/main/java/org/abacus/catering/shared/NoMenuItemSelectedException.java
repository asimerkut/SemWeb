package org.abacus.catering.shared;

import org.abacus.common.shared.AbcBusinessException;

public class NoMenuItemSelectedException extends AbcBusinessException {

}

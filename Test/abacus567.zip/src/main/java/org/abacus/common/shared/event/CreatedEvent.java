package org.abacus.common.shared.event;

public class CreatedEvent implements Event {
}

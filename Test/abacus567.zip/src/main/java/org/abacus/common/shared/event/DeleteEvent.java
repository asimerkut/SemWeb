package org.abacus.common.shared.event;

public class DeleteEvent implements Event {
}

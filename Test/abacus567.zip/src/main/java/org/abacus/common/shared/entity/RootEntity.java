package org.abacus.common.shared.entity;

import java.io.Serializable;

public interface RootEntity extends Serializable, Cloneable {

}

package org.abacus.transaction.shared;

import org.abacus.common.shared.AbcBusinessException;

@SuppressWarnings("serial")
public class UnableToCreateDetailException extends AbcBusinessException {

	public UnableToCreateDetailException(){
		
	}
	
}

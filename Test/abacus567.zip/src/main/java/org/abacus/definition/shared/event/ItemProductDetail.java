package org.abacus.definition.shared.event;

public class ItemProductDetail {

}

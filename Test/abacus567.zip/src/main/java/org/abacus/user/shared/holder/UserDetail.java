package org.abacus.user.shared.holder;

import java.util.List;

public class UserDetail {
	
	private String id;
	private String password;
	private Boolean active;
	private String organization;
	private List<String> groups;

}

package org.abacus.user.shared.event;

public class ReadUserGroupsEvent {

}

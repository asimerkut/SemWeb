package org.abacus.user.shared;

import org.abacus.common.shared.AbcBusinessException;

public class UserNameExistsException extends AbcBusinessException {

}

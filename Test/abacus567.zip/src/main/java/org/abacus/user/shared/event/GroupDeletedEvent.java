package org.abacus.user.shared.event;

import org.abacus.common.shared.event.DeletedEvent;

public class GroupDeletedEvent extends DeletedEvent{

}

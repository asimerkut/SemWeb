package org.abacus.user.shared.event;

import org.abacus.common.shared.event.RequestReadEvent;

public class RequestReadUserGroupsEvent extends RequestReadEvent {

}

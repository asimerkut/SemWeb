package org.abacus.message;

public class MsgNotification {

}
